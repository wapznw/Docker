find ../../ -type f -iname '*.php' | xgettext -L PHP --keyword="T_" -i --no-wrap -f -
